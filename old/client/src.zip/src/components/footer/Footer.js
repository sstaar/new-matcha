import React from 'react'

export const Footer = () => {
    return (
        <div className="footer">
                Made with 💛 @ 1337
        </div>
    )
}
